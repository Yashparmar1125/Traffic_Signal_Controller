import xmlrpc.client
from xmlrpc.server import SimpleXMLRPCServer
import threading
import time
import subprocess
import sys
import os
from collections import defaultdict

class DynamicLoadBalancer:
    def __init__(self):
        self.primary_server = {
            "url": "http://127.0.0.1:8000/", 
            "active_requests": 0, 
            "max_requests": 10,
            "port": 8000
        }
        
        # Dynamic clone tracking
        self.clone_servers = []
        self.next_clone_port = 8001
        self.clone_processes = {}  # port -> subprocess.Popen object
        
        self.lock = threading.Lock()
        self.total_requests = 0
        self.load_balanced_requests = 0
        self.clones_created = 0
        
        # Load balancing thresholds
        self.clone_threshold = 8  # Create clone when primary has 8+ requests
        self.max_clones = 3      # Maximum number of clones
        
    def get_total_capacity(self):
        """Get total system capacity"""
        total = self.primary_server["max_requests"]
        for clone in self.clone_servers:
            total += clone["max_requests"]
        return total
    
    def get_total_active_requests(self):
        """Get total active requests across all servers"""
        total = self.primary_server["active_requests"]
        for clone in self.clone_servers:
            total += clone["active_requests"]
        return total
    
    def should_create_clone(self):
        """Determine if we should create a new clone server"""
        with self.lock:
            # Don't create if we're at max clones
            if len(self.clone_servers) >= self.max_clones:
                return False
                
            # Create clone if primary is above threshold
            if self.primary_server["active_requests"] >= self.clone_threshold:
                return True
                
            return False
    
    def create_clone_server(self):
        """Dynamically create a new clone server"""
        if len(self.clone_servers) >= self.max_clones:
            print(f"🚫 Maximum clones ({self.max_clones}) already created")
            return None
            
        clone_port = self.next_clone_port
        self.next_clone_port += 1
        
        print(f"\n🔥 CREATING DYNAMIC CLONE SERVER:")
        print(f"   📡 Port: {clone_port}")
        print(f"   🎯 Reason: Primary server load = {self.primary_server['active_requests']}/{self.primary_server['max_requests']}")
        
        try:
            # Start clone server process
            clone_script = "server_clone_dynamic.py"
            process = subprocess.Popen([
                sys.executable, clone_script, str(clone_port)
            ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            
            # Give the server time to start
            time.sleep(2)
            
            # Check if process is still running
            if process.poll() is None:  # Process is still running
                # Add to our tracking
                clone_server = {
                    "url": f"http://127.0.0.1:{clone_port}/",
                    "active_requests": 0,
                    "max_requests": 10,
                    "port": clone_port
                }
                
                with self.lock:
                    self.clone_servers.append(clone_server)
                    self.clone_processes[clone_port] = process
                    self.clones_created += 1
                
                print(f"   ✅ Clone server created successfully on port {clone_port}")
                print(f"   📊 Total system capacity: {self.get_total_capacity()} requests")
                
                return clone_server
            else:
                print(f"   ❌ Failed to start clone server on port {clone_port}")
                return None
                
        except Exception as e:
            print(f"   ❌ Error creating clone server: {e}")
            return None
    
    def get_best_server(self):
        """Get the server with least load, creating clones if needed"""
        with self.lock:
            # Check if we need to create a clone
            if self.should_create_clone():
                # Release lock temporarily to create clone
                pass
            else:
                # Find server with least load
                all_servers = [self.primary_server] + self.clone_servers
                available_servers = [s for s in all_servers if s["active_requests"] < s["max_requests"]]
                
                if available_servers:
                    # Return server with least load
                    best_server = min(available_servers, key=lambda s: s["active_requests"])
                    server_index = 0 if best_server == self.primary_server else self.clone_servers.index(best_server) + 1
                    return server_index, best_server
                else:
                    # All servers full - return primary (will queue or reject)
                    print(f"⚠️ SYSTEM OVERLOAD: All servers at capacity!")
                    return 0, self.primary_server
        
        # Create clone outside of lock
        new_clone = self.create_clone_server()
        if new_clone:
            with self.lock:
                self.load_balanced_requests += 1
                return len(self.clone_servers), new_clone  # Return index of new clone
        
        # Fallback to primary if clone creation failed
        return 0, self.primary_server
    
    def increment_server_load(self, server_index):
        """Increment active request count for a server"""
        with self.lock:
            if server_index == 0:
                self.primary_server["active_requests"] += 1
                server = self.primary_server
            elif server_index <= len(self.clone_servers):
                self.clone_servers[server_index - 1]["active_requests"] += 1
                server = self.clone_servers[server_index - 1]
            else:
                return
                
            self.total_requests += 1
            print(f"📊 Server {server_index} (port {server['port']}) load: {server['active_requests']}/{server['max_requests']}")
    
    def decrement_server_load(self, server_index):
        """Decrement active request count for a server"""
        with self.lock:
            if server_index == 0:
                if self.primary_server["active_requests"] > 0:
                    self.primary_server["active_requests"] -= 1
            elif server_index <= len(self.clone_servers):
                if self.clone_servers[server_index - 1]["active_requests"] > 0:
                    self.clone_servers[server_index - 1]["active_requests"] -= 1
    
    def get_server_proxy(self, server_index):
        """Get XML-RPC proxy for specified server"""
        try:
            if server_index == 0:
                url = self.primary_server["url"]
            elif server_index <= len(self.clone_servers):
                url = self.clone_servers[server_index - 1]["url"]
            else:
                return None
                
            return xmlrpc.client.ServerProxy(url, allow_none=True)
        except Exception as e:
            print(f"❌ Failed to connect to server {server_index}: {e}")
            return None
    
    def route_request(self, method_name, *args, **kwargs):
        """Route request to appropriate server with dynamic scaling"""
        server_index, server = self.get_best_server()
        server_proxy = self.get_server_proxy(server_index)
        
        if not server_proxy:
            return None
        
        try:
            self.increment_server_load(server_index)
            
            # Log load balancing decisions
            if server_index > 0:
                print(f"⚖️ DYNAMIC LOAD BALANCING: Request routed to clone server (port {server['port']})")
            
            # Get the method from the server proxy
            method = getattr(server_proxy, method_name)
            result = method(*args, **kwargs)
            
            return result
        except Exception as e:
            print(f"❌ Error routing {method_name} to server {server_index}: {e}")
            return None
        finally:
            # Simulate request completion delay
            threading.Timer(5.0, lambda: self.decrement_server_load(server_index)).start()
    
    def get_load_balancer_stats(self):
        """Return comprehensive load balancer statistics"""
        with self.lock:
            stats = {
                "total_requests": self.total_requests,
                "load_balanced_requests": self.load_balanced_requests,
                "clones_created": self.clones_created,
                "active_clones": len(self.clone_servers),
                "max_clones": self.max_clones,
                "system_capacity": self.get_total_capacity(),
                "active_requests": self.get_total_active_requests(),
                "primary_load": f"{self.primary_server['active_requests']}/{self.primary_server['max_requests']}",
                "primary_url": self.primary_server["url"]
            }
            
            # Add clone server stats
            for i, clone in enumerate(self.clone_servers):
                stats[f"clone_{i+1}_load"] = f"{clone['active_requests']}/{clone['max_requests']}"
                stats[f"clone_{i+1}_url"] = clone["url"]
            
            return stats
    
    def cleanup(self):
        """Cleanup clone processes when shutting down"""
        print(f"\n🧹 CLEANING UP DYNAMIC CLONES:")
        for port, process in self.clone_processes.items():
            try:
                print(f"   🛑 Terminating clone server on port {port}")
                process.terminate()
                process.wait(timeout=5)
            except:
                try:
                    process.kill()
                except:
                    pass
        
        print(f"   ✅ All {len(self.clone_processes)} clone servers terminated")

# Global dynamic load balancer instance
dynamic_load_balancer = DynamicLoadBalancer()

# Wrapper functions for all the original server methods
def signal_manipulator(requested_signal):
    return dynamic_load_balancer.route_request("signal_manipulator", requested_signal)

def vip_signal_manipulator(requested_signal):
    return dynamic_load_balancer.route_request("vip_signal_manipulator", requested_signal)

def submit_vip_requests(vip_data):
    return dynamic_load_balancer.route_request("submit_vip_requests", vip_data)

def get_next_message():
    return dynamic_load_balancer.route_request("get_next_message")

def get_next_pedestrian_message():
    return dynamic_load_balancer.route_request("get_next_pedestrian_message")

def register_client_time(client_id, time_input):
    return dynamic_load_balancer.route_request("register_client_time", client_id, time_input)

def berkeley_synchronization():
    return dynamic_load_balancer.route_request("berkeley_synchronization")

def get_synchronized_time():
    return dynamic_load_balancer.route_request("get_synchronized_time")

def get_active_signal():
    return dynamic_load_balancer.route_request("get_active_signal")

def get_system_stats():
    # Combine system stats with load balancer stats
    system_stats = dynamic_load_balancer.route_request("get_system_stats")
    lb_stats = dynamic_load_balancer.get_load_balancer_stats()
    
    if system_stats:
        system_stats.update(lb_stats)
    
    return system_stats

def get_signal_status():
    return dynamic_load_balancer.route_request("get_signal_status")

if __name__ == "__main__":
    print("=" * 80)
    print("🔥 DYNAMIC LOAD BALANCER - TRAFFIC SIGNAL SYSTEM")
    print("📊 DYNAMIC SCALING: Creates clones when primary server is busy")
    print("🎯 CLONE THRESHOLD: Creates clone when primary has 8+ requests")
    print("🚀 AUTO-SCALING: Up to 3 clone servers (ports 8001, 8002, 8003)")
    print("⚖️ INTELLIGENT ROUTING: Routes to least loaded server")
    print("=" * 80)
    
    print("🔗 Starting Dynamic Load Balancer on port 9000...")
    print("📡 Primary server: http://127.0.0.1:8000/ (Max: 10 requests)")
    print("🔥 Clone servers: Created dynamically on ports 8001+")
    print("📊 Load monitoring: Real-time capacity management")
    print("=" * 80)
    
    server = SimpleXMLRPCServer(("127.0.0.1", 9000), allow_none=True)
    
    # Register all the wrapper functions
    server.register_function(signal_manipulator, "signal_manipulator")
    server.register_function(vip_signal_manipulator, "vip_signal_manipulator")
    server.register_function(submit_vip_requests, "submit_vip_requests")
    server.register_function(get_next_message, "get_next_message")
    server.register_function(get_next_pedestrian_message, "get_next_pedestrian_message")
    server.register_function(register_client_time, "register_client_time")
    server.register_function(berkeley_synchronization, "berkeley_synchronization")
    server.register_function(get_synchronized_time, "get_synchronized_time")
    server.register_function(get_active_signal, "get_active_signal")
    server.register_function(get_system_stats, "get_system_stats")
    server.register_function(get_signal_status, "get_signal_status")
    
    print("🔥 Dynamic Load Balancer ready! Will create clones as needed...")
    
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n🛑 Dynamic Load Balancer stopped manually.")
        
        # Show final statistics
        stats = dynamic_load_balancer.get_load_balancer_stats()
        print("\n📈 FINAL LOAD BALANCER STATISTICS:")
        print(f"   Total requests handled: {stats['total_requests']}")
        print(f"   Load balanced requests: {stats['load_balanced_requests']}")
        print(f"   Clones created dynamically: {stats['clones_created']}")
        print(f"   Final system capacity: {stats['system_capacity']} requests")
        print(f"   Peak concurrent clones: {stats['active_clones']}")
        
        # Cleanup clone processes
        dynamic_load_balancer.cleanup()